#include"play.h"
#include"game.h"
void Display::welcome() {

	cout << "                                                                 " << endl;
	cout << "           #####                                                 " << endl;
	cout << "           ##  ##                     #    ##                   " << endl;
	cout << "           ##   ##    #####  ######   #   ######                " << endl;
	cout << "           ##   ##    ## ##  ##  ##        ##                   " << endl;
	cout << "           ##   ##    ## ##  ##  ##        ##                   " << endl;
	cout << "           ######     #####  ##  ##        #####                " << endl << endl;

	cout << "                                                   ##                    " << endl;
	cout << "          ##      ######    ##    ##    #####      ##                    " << endl;
	cout << "       ########  ##    ##   ##    ##   ##    #     #######                 " << endl;
	cout << "          ##     ##    ##   ##    ##   ##          ##   ##                 " << endl;
	cout << "          ##     ##    ##   ##    ##   ##    #     ##   ##                " << endl;
	cout << "          #####   ######     ######     #####      ##   ##                  " << endl;
	cout << "                                                                  " << endl;
	cout << "     $$        $$                               $$    $$         " << endl;
	cout << "     $$        $$                   $$$$$       $$  $$       " << endl;
	cout << "     $$        $$     $$$$$        $$    $      $$$$          " << endl;
	cout << "     $$$$$$    $$    $$    $$      $$           $$$$         " << endl;
	cout << "     $$   $$   $$    $$    $$      $$    $      $$  $$        " << endl;
	cout << "     $$$$$$    $$     $$$$  $$      $$$$$       $$    $$    " << endl << endl;
	cout << "     ��Ϸ���򣺰��� 1��2��3��4 ���ּ����㶨������Ŀ��" << endl << endl;
	cout << "\t\t";

	system("PAUSE");
}

int Display::show(int t, int k, Pitch &pitch) {

	system("cls");
	int i;//����ֵ

	SYSTEMTIME time;
	GetLocalTime(&time);

	score += addscore;
	if (k == 9) {
		x = (time.wMilliseconds / 100 % 4) + 1;
		if (addscore == 0)
			cout << "===================��ǰ�÷֣�" << score << " ========================" << endl << endl;
		else
			cout << "===================��ǰ�÷֣�" << score << " + " << addscore << " ===================" << endl << endl;
		addscore = (time.wMilliseconds % 50 + 50);
		
	}

	else
		x = (pitch.str[pitch.i + 4]) % 4 + 1;



	if (k == 9)
	{
		if (t < 99999) {
			switch (d) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}

			switch (c) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
			switch (b) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
			switch (a) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
		}


	}
	else {
		if (t < pitch.number - 3) {
			switch (d) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}

			switch (c) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
			switch (b) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
			switch (a) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
		}

		else {
			cout << endl << endl << endl << endl << endl << endl;
			if (t < pitch.number - 2) {
				switch (c) {
				case 1:
					b1();
					break;
				case 2:
					b2();
					break;
				case 3:
					b3();
					break;
				case 4:
					b4();
					break;
				}
			}
			else { cout << endl << endl << endl << endl << endl << endl; }
			if (t < pitch.number - 1) {
				switch (b) {
				case 1:
					b1();
					break;
				case 2:
					b2();
					break;
				case 3:
					b3();
					break;
				case 4:
					b4();
					break;
				}
			}
			else { cout << endl << endl << endl << endl << endl << endl; }
			if (t < pitch.number) {
				switch (a) {
				case 1:
					b1();
					break;
				case 2:
					b2();
					break;
				case 3:
					b3();
					break;
				case 4:
					b4();
					break;
				}
			}
			else { cout << "............................................................" << endl << "............................................................" << endl << "............................................................" << endl << "............................................................" << endl << "............................................................" << endl; }
		}
	}





	i = a;
	a = b; b = c; c = d; d = x;

	cout << endl << " 1111111111111   2222222222222   3333333333333   4444444444444" << endl;


	return i;
}

void Display::b1() {
	color(255);

	cout << "###############" << endl;
	cout << "###############" << endl;
	cout << "###############" << endl;
	cout << "###############" << endl;
	cout << "###############" << endl;
	cout << "###############" << endl;
	color(7);
}
void Display::b2() {
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl;
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl;
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl;
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl;
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl;
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl;
	color(7);
}
void Display::b3() {
	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;
	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;
	color(7);
}

void Display::b4() {
	color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl;
	color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl; color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl; color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl; color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl; color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl;
	color(7);
}

void Display::fail() {
	system("cls");

	cout << "                                                                 " << endl;
	cout << "       ###                                 ###                   " << endl;
	cout << "         ###                             ###                     " << endl;
	cout << "           ###                         ###                       " << endl;
	cout << "             ###                     ###                         " << endl;
	cout << "               ###                 ###                           " << endl;
	cout << "                 ###             ###                             " << endl;
	cout << "                   ###         ###                               " << endl;
	cout << "                     ###     ###                                 " << endl;
	cout << "                       ### ###                                   " << endl;
	cout << "                         ###                                     " << endl;
	cout << "                       ### ###                                   " << endl;
	cout << "                     ###     ###                                 " << endl;
	cout << "                   ###         ###                               " << endl;
	cout << "                 ###             ###                             " << endl;
	cout << "               ###                 ###                           " << endl;
	cout << "             ###                     ###                         " << endl;
	cout << "           ###                         ###                       " << endl;
	cout << "         ###                             ###                     " << endl;
	cout << "       ###                                 ###                   " << endl << endl;


	//Ӧ�����������һ������
	Beep((DWORD)1000, (DWORD)500);


}

void Display::win(double score) {
	system("cls");
	cout << "you win!" << endl;
	cout << "��ǰ��ʱ��" << score << 's' << endl;

}

void Display::inital(int j, Pitch & pitch)
{

	score = 0;
	addscore = 0;
	int i;
	switch (j)
	{
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	case 8:
		a = (pitch.str[0]) % 4 + 1;
		b = (pitch.str[1]) % 4 + 1;
		c = (pitch.str[2]) % 4 + 1;
		d = (pitch.str[3]) % 4 + 1;
		break;

	case 9:

		SYSTEMTIME time;
		GetLocalTime(&time);
		i = time.wMilliseconds;
		a = (i % 4) + 1;
		b = (i / 10 % 4) + 1;
		c = (i / 100 % 4) + 1;
		d = (a + b + c) % 4 + 1;

		break;


	}

}

void Display::infinite_end(double timescore, Data&data) {
	system("cls");
	cout << "game over!" << endl;
	cout << "��ǰ�÷֣�" << score << endl;
	cout << "��ʱ��" << timescore << 's' << endl;
	data.SaveGame(score);
	//���ļ��õ���¼���������

}



void Pitch::Rf_pitch(int pin) {
	i = 0;
	ifstream in;
	if (pin == 1)
		in.open("..//Debug//FILE//game//game1.txt");
	else if (pin == 2)
		in.open("..//Debug//FILE//game//game2.txt");
	else if (pin == 3)
		in.open("..//Debug//FILE//game//game3.txt");
	else if (pin == 4)
		in.open("..//Debug//FILE//game//game4.txt");
	else if (pin == 5)
		in.open("..//Debug//FILE//game//game5.txt");
	else if (pin == 6)
		in.open("..//Debug//FILE//game//game6.txt");
	else if (pin == 7)
		in.open("..//Debug//FILE//game//game7.txt");
	else if (pin == 8)
		in.open("..//Debug//FILE//game//game8.txt");
	

	else return;

	if (!in.is_open())
	{
		cout << "Error opening file"; exit(1);
	}

	while (!in.eof())
	{
		in >> number;
		for (int i = 0; i < number; i++) {
			in >> str[i];
		}
		break;
	}
	in.close();

}

void Pitch::playpitch() {

	if (str[i] == 1) {
		PlaySound(TEXT("FILE\\pitch\\1.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == 2) {
		PlaySound(TEXT("FILE\\pitch\\2.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 3) {
		PlaySound(TEXT("FILE\\pitch\\3.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 4) {
		PlaySound(TEXT("FILE\\pitch\\4.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 5) {
		PlaySound(TEXT("FILE\\pitch\\5.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 6) {
		PlaySound(TEXT("FILE\\pitch\\6.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 7) {
		PlaySound(TEXT("FILE\\pitch\\7.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 8) {
		PlaySound(TEXT("FILE\\pitch\\8.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 9) {
		PlaySound(TEXT("FILE\\pitch\\9.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 10) {
		PlaySound(TEXT("FILE\\pitch\\10.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 11) {
		PlaySound(TEXT("FILE\\pitch\\11.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 12) {
		PlaySound(TEXT("FILE\\pitch\\12.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == 47) {
		PlaySound(TEXT("FILE\\pitch\\47.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
}
void Pitch::playpitch(char k) {
	
	if (k == '1') {
		PlaySound(TEXT("FILE\\pitch\\1.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (k == '2') {
		PlaySound(TEXT("FILE\\pitch\\2.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == '3') {
		PlaySound(TEXT("FILE\\pitch\\3.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == '4') {
		PlaySound(TEXT("FILE\\pitch\\4.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == '5') {
		PlaySound(TEXT("FILE\\pitch\\5.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == '6') {
		PlaySound(TEXT("FILE\\pitch\\6.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == '7') {
		PlaySound(TEXT("FILE\\pitch\\7.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == 'q') {
		PlaySound(TEXT("FILE\\pitch\\8.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == 'w') {
		PlaySound(TEXT("FILE\\pitch\\9.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == 'e') {
		PlaySound(TEXT("FILE\\pitch\\10.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == 'r') {
		PlaySound(TEXT("FILE\\pitch\\11.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == 't') {
		PlaySound(TEXT("FILE\\pitch\\12.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == 'y') {
		PlaySound(TEXT("FILE\\pitch\\13.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (k == 'u') {
		PlaySound(TEXT("FILE\\pitch\\14.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

}

float Data::Mintime(float rank[100]) {
	int i = 0, j = 0;
	while (i < 100) {
		if (rank[i] <rank[j])j = i;
		i++;
	}
	return rank[j];
}
int Data::NormalMaxScore(int rank[100]) {
	int i = 0, j = 0;
	while (i < 100) {
		if (rank[i] >rank[j])j = i;
		i++;
	}
	return rank[j];
}
float Data::tran(char* p) {
	int i = 0, j = 0;
	bool flag = 1;
	float sum = 0;
	while (p[i] != '\0') {
		if (p[i] == '.')flag = 0;
		if (flag == 1) {
			if (i == 0)sum += ((int)p[i] - 48);
			else sum = sum * 10 + ((int)p[i] - 48);
		}
		if (flag == 0 && p[i] != '.') {
			if (j == 0)sum = sum + ((int)p[i] - 48) / 10.0;
			if (j == 1)sum = sum + ((int)p[i] - 48) / 100.0;
			if (j == 2)sum = sum + ((int)p[i] - 48) / 1000.0;
			j++;
		}
		i++;
	}
	return sum;
}
void Data::SaveGame(double timescore) {
	//system("cls");
	fstream fs;
	fs.open("NormalGameScore.txt", ios::app | ios::ate);
	if (!fs.is_open()) {
		cout << "Open NormalGameScore.txt error!" << endl;
		return;
	}
	fs << timescore << endl;//��ÿһ�ε�ͨ��ʱ����뵽NormalGameScore.txt
	fs.close();


	char str[10] = { 0 };
	int count = 10;
	stack<string>s;//��stack�ṹ������µ�ʮ����Ϸ��¼
	float rank[100] = { 0 };//���ֻ�Ǵ�100����Ϸ������
	int i = 0;//i������������ǰ��ֵ��һ������
	while (i < 100) {
		rank[i] = 10000;
		i++;
	}//�������ʼ������ΪҪ�ҳ���С��ʱ�䡣����һ���ܴ��ֵ��������
	i = 0;//�ٽ�i���0��

	fs.open("NormalGameScore.txt", ios::in);
	cout << "�������Ϸ��¼Ϊ��" << endl;
	while (fs.getline(str, sizeof(str))) {
		s.push(str);
		rank[i] = tran(str);
		i++;
	}
	fs.close();

	//������µ�ʮ�γɼ���
	while (count--) {
		if (!s.empty()) {
			cout << s.top() << "s" << endl;
			s.pop();
		}
	}
	while (!s.empty())s.pop();

	//�����óɼ���
	cout << "����ٶ�ͨ���ǣ�" << Mintime(rank) << "s" << endl;


}
void Data::SaveGame(int score) {
	fstream fs;
	fs.open("InfiniteGameScore.txt", ios::app | ios::ate);
	if (!fs.is_open()) {
		cout << "Open InfiniteGameScore.txt error!" << endl;
		return;
	}
	fs << score << endl;//��ÿһ�ε�ͨ��ʱ����뵽NormalGameScore.txt
	fs.close();


	char str[10] = { 0 };
	int count = 10;
	stack<string>s;//��stack�ṹ������µ�ʮ����Ϸ��¼
	int rank[100] = { 0 };//���ֻ�Ǵ�100����Ϸ������
	int i = 0;//i������������ǰ��ֵ��һ������
	rank[i] = { 0 };

	fs.open("InfiniteGameScore.txt", ios::in);
	cout << "�������Ϸ��¼Ϊ��" << endl;
	while (fs.getline(str, sizeof(str))) {
		s.push(str);
		rank[i] = tran(str);
		i++;
	}
	fs.close();

	//������µ�ʮ�γɼ���
	while (count--) {
		if (!s.empty()) {
			cout << s.top() << endl;
			s.pop();
		}
	}
	while (!s.empty())s.pop();

	//�����óɼ���
	cout << "��߷֣�" << NormalMaxScore(rank) << endl;


}


void Data::SaveGame(double timesocre, Display&block) {

}

void Data::LoadGame(int k) {
	if (k == 9) {}//����ģʽ
	else {}
}