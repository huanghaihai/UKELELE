#include"play.h"
#include"game.h"

void color(int a)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), a);
}
void Keyboard::sounds(char in) {
	int i = in - '0' - 1;
	if (str[i] == "E") {
		PlaySound(TEXT("FILE\\sounds\\1.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == "B") {
		PlaySound(TEXT("FILE\\sounds\\2.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == "#Cm") {
		PlaySound(TEXT("FILE\\sounds\\3.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == "bAm") {
		PlaySound(TEXT("FILE\\sounds\\4.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "A") {
		PlaySound(TEXT("FILE\\sounds\\5.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "bE") {
		PlaySound(TEXT("FILE\\sounds\\6.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "Cm") {
		PlaySound(TEXT("FILE\\sounds\\7.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "bA") {
		PlaySound(TEXT("FILE\\sounds\\8.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "bB") {
		PlaySound(TEXT("FILE\\sounds\\9.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "Fm") {
		PlaySound(TEXT("FILE\\sounds\\10.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "Gm.") {
		PlaySound(TEXT("FILE\\sounds\\11.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "G.") {
		PlaySound(TEXT("FILE\\sounds\\12.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "F.") {
		PlaySound(TEXT("FILE\\sounds\\13.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "Em.") {
		PlaySound(TEXT("FILE\\sounds\\14.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "Am.") {
		PlaySound(TEXT("FILE\\sounds\\15.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "Dm.") {
		PlaySound(TEXT("FILE\\sounds\\16.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "C.") {
		PlaySound(TEXT("FILE\\sounds\\17.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "A.") {
		PlaySound(TEXT("FILE\\sounds\\18.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == "bA.") {
		PlaySound(TEXT("FILE\\sounds\\19.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "bB.") {
		PlaySound(TEXT("FILE\\sounds\\20.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "bE.") {
		PlaySound(TEXT("FILE\\sounds\\21.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "Cm.") {
		PlaySound(TEXT("FILE\\sounds\\22.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
	else if (str[i] == "Fm.") {
		PlaySound(TEXT("FILE\\sounds\\23.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}
}
int Container::react(char in) {
	if (in == '0')return 0;
	sounds(in);
	initialtitle();
	changecolor(in);
	Sleep(200);
	changetitle(in);
	initialcolor();
	return 1;
}
void Keyboard::initialcolor() {

	for (int i = 0; i < number; i++) {
		color(kb_color.origin_color[i]);
		cout << setw(4) << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;
	for (int i = 0; i < number; i++) {
		color(kb_color.origin_color[i]);
		cout << setw(3) << str[i] << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;
	for (int i = 0; i < number; i++) {
		color(kb_color.origin_color[i]);

		cout << setw(4) << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;

}
void Keyboard::changecolor(char k) {

	int kk = k - '0' - 1;
	switch (k) {
	case 'q':
		kk = 7;
		break;
	case 'w':
		kk = 8;
		break;
	case 'e':
		kk = 9;
		break;
	case 'r':
		kk = 10;
		break;
	case 't':
		kk = 11;
		break;
	case 'y':
		kk = 12;
		break;
	case 'u':
		kk = 13;
		break;

	}







	for (int i = 0; i<number; i++) {
		if (i == kk) {
			color(kb_color.change_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_color.origin_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
	}

	cout << endl;
	for (int i = 0; i<number; i++) {
		if (i == kk)
		{
			color(kb_color.change_color[i]);
			cout << setw(3) << str[i] << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_color.origin_color[i]);
			cout << setw(3) << str[i] << " ";
			color(15);
			cout << "  ";
		}

	}
	cout << endl;
	for (int i = 0; i<number; i++) {
		if (i == kk) {
			color(kb_color.change_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_color.origin_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
	}
	cout << endl;


}
void title::initialtitle() {
	system("cls");
	for (int i = 0; i <= line; i++) {
		for (int j = 0; j< 20; j++) {
			if (mark_i == i&&mark_j == j) {
				color(tt_color.origin_color[key_words[i][j] - 1]);
				cout << "�z";
				color(7);

			}
			else if (key_words[i][j] != 0)
			{
				color(tt_color.origin_color[key_words[i][j] - 1]);
				cout << "�x";//�z
				color(7);
			}
			else cout << "  ";
		}
		cout << endl;
		cout << song_words[i] << endl;
	}
	cout << endl << endl;
}
void title::changetitle(char k) {
	system("cls");
	int num = 0;
	int flag = 0;

	for (int i = 0; i <= line; i++) {
		for (int j = 0; j< 20; j++) {
			if (key_words[i][j] != 0)
			{
				num++;

				if (key_words[i][j] != k - '0'&&i == mark_i&&j == mark_j)
				{
					color(tt_color.change_color[key_words[i][j] - 1]);
					cout << "�z";
					color(7);

				}

				else if (i == mark_i&&j == mark_j) {

					color(tt_color.origin_color[key_words[i][j] - 1]);
					cout << "�x";
					color(7);
					Count++;
					mark_i = mark[Count][0];
					mark_j = mark[Count][1];
					k = -1;
				}

				else if (key_words[i][j] != k - '0'&&i == mark_i&&j == mark_j)
				{
					color(tt_color.change_color[key_words[i][j] - 1]);
					cout << "�z";
					color(7);

				}


				else {
					color(tt_color.origin_color[key_words[i][j] - 1]);
					cout << "�x";
					color(7);
				}

			}
			else cout << "  ";
		}
		cout << endl;
		cout << song_words[i] << endl;
	}
	cout << endl << endl;
}

void Keyboard::Rf_keyboard(int i) {
	ifstream in;
	if (i == 1)
		in.open("..//Debug//FILE//play_songs//keyboard1.txt");
	else if (i == 2)
		in.open("..//Debug//FILE//play_songs//keyboard2.txt");
	else if (i == 3)
		in.open("..//Debug//FILE//play_songs//keyboard3.txt");
	else if (i == 4)
		in.open("..//Debug//FILE//play_songs//keyboard4.txt");
	else if (i == 5)
		in.open("..//Debug//FILE//play_songs//keyboard5.txt");
	else if(i==99)
		in.open("..//Debug//FILE//play_songs//keyboard99.txt");


	else return;

	if (!in.is_open())
	{
		cout << "Error opening file"; exit(1);
	}

	while (!in.eof())
	{
		in >> number;
		for (int i = 0; i < number; i++) {
			in >> str[i];
		}
	}
	in.close();
}

void title::Rf_title(int i) {

	memset(key_words, 0, sizeof(key_words));
	ifstream in;
	if (i == 1)
		in.open("..//Debug//FILE//play_songs//title1.txt");
	else if (i == 2)
		in.open("..//Debug//FILE//play_songs//title2.txt");
	else if (i == 3)
		in.open("..//Debug//FILE//play_songs//title3.txt");
	else if (i == 4)
		in.open("..//Debug//FILE//play_songs//title4.txt");
	else if (i == 5)
		in.open("..//Debug//FILE//play_songs//title5.txt");

	else return;

	if (!in.is_open())
	{
		cout << "Error opening file"; exit(1);
	}
	while (!in.eof())
	{
		in >> line;
		for (int i = 0; i <= line; i++) {
			in >> song_words[i];
		}
		int a = 0;
		while (!in.eof()) {
			int j, k, temp;
			in >> j >> k >> temp;
			key_words[j][k] = temp;
			mark[a][0] = j;
			mark[a][1] = k;
			if (a == 0) { mark_i = j; mark_j = k; }
			a++;
		}
	}
	in.close();
}