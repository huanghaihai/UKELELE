#pragma once
#include <stdio.h>
#include<conio.h>
#include<iostream>
#include <windows.h>
#include <mmsystem.h>
#include<string>
#include<string.h>
#include <iomanip>
#include <fstream>
#include <stdlib.h>

#pragma comment(lib, "winmm.lib")
using namespace std;
void color(int);

class kordform {
public:
	string str[5];
	int code[5];
	int origin_color[5];
	int change_color[5];
	kordform() {
		str[0] = "E";
		str[1] = "B";
		str[2] = "#Cm";
		str[3] = "bAm";
		str[4] = "A";
		code[0] = 0;
		code[1] = 1;
		code[2] = 2;
		code[3] = 3;
		code[4] = 4;
		origin_color[0] = 64;
		origin_color[1] = 96;
		origin_color[2] = 32;
		origin_color[3] = 48;
		origin_color[4] = 80;

		change_color[0] = 192;
		change_color[1] = 224;
		change_color[2] = 160;
		change_color[3] = 176;
		change_color[4] = 208;

	}
	kordform(int) {
		str[0] = "E";
		str[1] = "B";
		str[2] = "#Cm";
		str[3] = "bAm";
		str[4] = "A";
		code[0] = 0;
		code[1] = 1;
		code[2] = 2;
		code[3] = 3;
		code[4] = 4;
		origin_color[0] = 4;
		origin_color[1] = 6;
		origin_color[2] = 2;
		origin_color[3] = 9;
		origin_color[4] = 5;

		change_color[0] = 12;
		change_color[1] = 14;
		change_color[2] = 10;
		change_color[3] = 11;
		change_color[4] = 13;
	}
};
class Keyboard {
private:
	string str[10];
	int number;
	kordform kb_kord;

public:
	char in;
	void changecolor(char);
	void sounds();
	void getin() { in = _getch(); }
	void initialcolor();
	void Rf_keyboard(int);
};
class title {
private:
	string song_words[20];
	int key_words[20][20];
	int mark[20][2];
	int line;
	kordform tt_kord;
	int mark_i;
	int mark_j;

public:
	int Count;
	title() :tt_kord(1) {
		mark_i = 0;
		mark_j = 0;
		Count = 0;
	}
	void Rf_title(int);
	void initialtitle();
	void changetitle(char);
};

class Container :public Keyboard, public title
{
public:
	int react();
};

void color(int a)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), a);
}
void Keyboard::sounds() {
	int i = in - '0' - 1;
	if (str[i] == "E") {
		PlaySound(TEXT("Debug\\sounds\\1.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == "B") {
		PlaySound(TEXT("Debug\\sounds\\2.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == "#Cm") {
		PlaySound(TEXT("Debug\\sounds\\3.wav"), NULL, SND_ASYNC | SND_NODEFAULT);

	}

	else if (str[i] == "bAm") {
		PlaySound(TEXT("Debug\\sounds\\4.wav"), NULL, SND_ASYNC | SND_NODEFAULT);

	}
	else if (str[i] == "A") {
		PlaySound(TEXT("Debug\\sounds\\5.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}


}
int Container::react() {
	if (in == '0')return 0;
	sounds();
	initialtitle();
	changecolor(in);
	Sleep(500);
	changetitle(in);
	initialcolor();
	return 1;
}
void Keyboard::initialcolor() {

	for (int i = 0; i < number; i++) {
		color(kb_kord.origin_color[i]);
		cout << setw(4) << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;
	for (int i = 0; i < number; i++) {
		color(kb_kord.origin_color[i]);
		cout << setw(3) << str[i] << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;
	for (int i = 0; i < number; i++) {
		color(kb_kord.origin_color[i]);

		cout << setw(4) << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;

}
void Keyboard::changecolor(char k) {
	for (int i = 0; i<number; i++) {
		if (i == k - '0' - 1) {
			color(kb_kord.change_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_kord.origin_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
	}

	cout << endl;
	for (int i = 0; i<number; i++) {
		if (i == k - '0' - 1)
		{
			color(kb_kord.change_color[i]);
			cout << setw(3) << str[i] << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_kord.origin_color[i]);
			cout << setw(3) << str[i] << " ";
			color(15);
			cout << "  ";
		}

	}
	cout << endl;
	for (int i = 0; i<number; i++) {
		if (i == k - '0' - 1) {
			color(kb_kord.change_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_kord.origin_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
	}
	cout << endl;


}
void title::initialtitle() {
	system("cls");
	for (int i = 0; i <= line; i++) {
		for (int j = 0; j< 20; j++) {
			if (i == 0 && j == 0 && mark_i == 0 && mark_j == 0) {
				color(tt_kord.origin_color[key_words[i][j] - 1]);
				cout << "�z";
				color(7);
			}
			else if (key_words[i][j] != 0)
			{
				color(tt_kord.origin_color[key_words[i][j] - 1]);
				cout << "�x";//�z
				color(7);
			}
			else cout << "  ";
		}
		cout << endl;
		cout << song_words[i] << endl;
	}
	cout << endl << endl;
}
void title::changetitle(char k) {
	system("cls");
	int num = 0;
	int flag = 0;

	for (int i = 0; i <= line; i++) {
		for (int j = 0; j< 20; j++) {
			if (key_words[i][j] != 0)
			{
				num++;

				if (key_words[i][j] == k - '0'&&i == mark_i&&j == mark_j) {
					color(tt_kord.origin_color[key_words[i][j] - 1]);
					cout << "�x";
					color(7);
					Count++;
					mark_i = mark[Count][0];
					mark_j = mark[Count][1];
					continue;
				}

				else if (key_words[i][j] != k - '0'&&i == mark_i&&j == mark_j)
				{
					color(tt_kord.change_color[key_words[i][j] - 1]);
					cout << "�z";
					color(7);

				}


				else {
					color(tt_kord.origin_color[key_words[i][j] - 1]);
					cout << "�x";
					color(7);
				}

			}
			else cout << "  ";
		}
		cout << endl;
		cout << song_words[i] << endl;
	}
	cout << endl << endl;
}

void Keyboard::Rf_keyboard(int i) {
	ifstream in;
	if (i == 1)
		in.open("..//keyboard1.txt");
	else return;

	if (!in.is_open())
	{
		cout << "Error opening file"; exit(1);
	}

	while (!in.eof())
	{
		in >> number;
		for (int i = 0; i < number; i++) {
			in >> str[i];
		}
	}

}

void title::Rf_title(int i) {

	memset(key_words, 0, sizeof(key_words));
	ifstream in;
	if (i == 1)
		in.open("..//title1.txt");
	else return;

	if (!in.is_open())
	{
		cout << "Error opening file"; exit(1);
	}
	while (!in.eof())
	{
		in >> line;
		for (int i = 0; i <= line; i++) {
			in >> song_words[i];
		}
		int a = 0;
		while (!in.eof()) {
			int j, k, temp;
			in >> j >> k >> temp;
			key_words[j][k] = temp;
			mark[a][0] = j;
			mark[a][1] = k;
			a++;
		}
	}

}