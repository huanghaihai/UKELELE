#pragma once
#include <stdio.h>
#include<conio.h>
#include<iostream>
#include <windows.h>
#include <mmsystem.h>
#include<string>
#include<string.h>
#include <iomanip>
#include <fstream>
#include <stdlib.h>

#pragma comment(lib, "winmm.lib")
using namespace std;
void color(int);

class kordform {
public:
	string str[5];
	int code[5];
	int origin_color[5];
	int change_color[5];
	kordform() {
		str[0] = "E";
		str[1] = "B";
		str[2] = "#Cm";
		str[3] = "bAm";
		str[4] = "A";
		code[0] = 0;
		code[1] = 1;
		code[2] = 2;
		code[3] = 3;
		code[4] = 4;
		origin_color[0] = 64;
		origin_color[1] = 96;
		origin_color[2] = 32;
		origin_color[3] = 48;
		origin_color[4] = 80;

		change_color[0] = 192;
		change_color[1] = 224;
		change_color[2] = 160;
		change_color[3] = 176;
		change_color[4] = 208;

	}
	kordform(int) {
		str[0] = "E";
		str[1] = "B";
		str[2] = "#Cm";
		str[3] = "bAm";
		str[4] = "A";
		code[0] = 0;
		code[1] = 1;
		code[2] = 2;
		code[3] = 3;
		code[4] = 4;
		origin_color[0] = 4;
		origin_color[1] = 6;
		origin_color[2] = 2;
		origin_color[3] = 9;
		origin_color[4] = 5;

		change_color[0] = 12;
		change_color[1] = 14;
		change_color[2] = 10;
		change_color[3] = 11;
		change_color[4] = 13;
	}
};
class Keyboard {
private:
	string str[10];
	int number;
	kordform kb_kord;

public:
	char in;
	void changecolor(char);
	void sounds();
	void getin() { in = _getch(); }
	void initialcolor();
	void Rf_keyboard(int);
};
class title {
private:
	string song_words[20];
	int key_words[20][20];
	int mark[20][2];
	int line;
	kordform tt_kord;
	int mark_i;
	int mark_j;

public:
	int Count;
	title() :tt_kord(1) {
		mark_i = 0;
		mark_j = 0;
		Count = 0;
	}
	void Rf_title(int);
	void initialtitle();
	void changetitle(char);
};
class Container :public Keyboard, public title
{
public:
	int react();
};

