#include"myhead.h"

void color(int a)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), a);
}
void Keyboard::sounds() {
	int i = in - '0' - 1;
	if (str[i] == "E") {
		PlaySound(TEXT("FILE\\sounds\\1.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == "B") {
		PlaySound(TEXT("FILE\\sounds\\2.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}

	else if (str[i] == "#Cm") {
		PlaySound(TEXT("FILE\\sounds\\3.wav"), NULL, SND_ASYNC | SND_NODEFAULT);

	}

	else if (str[i] == "bAm") {
		PlaySound(TEXT("FILE\\sounds\\4.wav"), NULL, SND_ASYNC | SND_NODEFAULT);

	}
	else if (str[i] == "A") {
		PlaySound(TEXT("FILE\\sounds\\5.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
	}


}
int Container::react() {
	if (in == '0')return 0;
	sounds();
	initialtitle();
	changecolor(in);
	Sleep(500);
	changetitle(in);
	initialcolor();
	return 1;
}
void Keyboard::initialcolor() {

	for (int i = 0; i < number; i++) {
		color(kb_kord.origin_color[i]);
		cout << setw(4) << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;
	for (int i = 0; i < number; i++) {
		color(kb_kord.origin_color[i]);
		cout << setw(3) << str[i] << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;
	for (int i = 0; i < number; i++) {
		color(kb_kord.origin_color[i]);

		cout << setw(4) << " ";
		color(7);
		cout << "  ";
	}
	cout << endl;

}
void Keyboard::changecolor(char k) {
	for (int i = 0; i<number; i++) {
		if (i == k - '0' - 1) {
			color(kb_kord.change_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_kord.origin_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
	}

	cout << endl;
	for (int i = 0; i<number; i++) {
		if (i == k - '0' - 1)
		{
			color(kb_kord.change_color[i]);
			cout << setw(3) << str[i] << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_kord.origin_color[i]);
			cout << setw(3) << str[i] << " ";
			color(15);
			cout << "  ";
		}

	}
	cout << endl;
	for (int i = 0; i<number; i++) {
		if (i == k - '0' - 1) {
			color(kb_kord.change_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
		else {
			color(kb_kord.origin_color[i]);
			cout << setw(4) << " ";
			color(15);
			cout << "  ";
		}
	}
	cout << endl;


}
void title::initialtitle() {
	system("cls");
	for (int i = 0; i <= line; i++) {
		for (int j = 0; j< 20; j++) {
			if (i == 0 && j == 0 && mark_i == 0 && mark_j == 0) {
				color(tt_kord.origin_color[key_words[i][j] - 1]);
				cout << "�z";
				color(7);
			}
			else if (key_words[i][j] != 0)
			{
				color(tt_kord.origin_color[key_words[i][j] - 1]);
				cout << "�x";//�z
				color(7);
			}
			else cout << "  ";
		}
		cout << endl;
		cout << song_words[i] << endl;
	}
	cout << endl << endl;
}
void title::changetitle(char k) {
	system("cls");
	int num = 0;
	int flag = 0;

	for (int i = 0; i <= line; i++) {
		for (int j = 0; j< 20; j++) {
			if (key_words[i][j] != 0)
			{
				num++;

				if (key_words[i][j] == k - '0'&&i == mark_i&&j == mark_j) {
					color(tt_kord.origin_color[key_words[i][j] - 1]);
					cout << "�x";
					color(7);
					Count++;
					mark_i = mark[Count][0];
					mark_j = mark[Count][1];
					continue;
				}

				else if (key_words[i][j] != k - '0'&&i == mark_i&&j == mark_j)
				{
					color(tt_kord.change_color[key_words[i][j] - 1]);
					cout << "�z";
					color(7);

				}


				else {
					color(tt_kord.origin_color[key_words[i][j] - 1]);
					cout << "�x";
					color(7);
				}

			}
			else cout << "  ";
		}
		cout << endl;
		cout << song_words[i] << endl;
	}
	cout << endl << endl;
}

void Keyboard::Rf_keyboard(int i) {
	ifstream in;
	if (i == 1)
		in.open("..//Debug//FILE//play_songs//keyboard1.txt");
	else return;

	if (!in.is_open())
	{
		cout << "Error opening file"; exit(1);
	}

	while (!in.eof())
	{
		in >> number;
		for (int i = 0; i < number; i++) {
			in >> str[i];
		}
	}

}

void title::Rf_title(int i) {

	memset(key_words, 0, sizeof(key_words));
	ifstream in;
	if (i == 1)
		in.open("..//Debug//FILE//play_songs//title1.txt");
	else return;

	if (!in.is_open())
	{
		cout << "Error opening file"; exit(1);
	}
	while (!in.eof())
	{
		in >> line;
		for (int i = 0; i <= line; i++) {
			in >> song_words[i];
		}
		int a = 0;
		while (!in.eof()) {
			int j, k, temp;
			in >> j >> k >> temp;
			key_words[j][k] = temp;
			mark[a][0] = j;
			mark[a][1] = k;
			a++;
		}
	}

}