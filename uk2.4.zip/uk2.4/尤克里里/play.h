#pragma once
#include <stdio.h>
#include<conio.h>
#include<iostream>
#include <windows.h>
#include <mmsystem.h>
#include<string>
#include<string.h>
#include <iomanip>
#include <fstream>
#include <stdlib.h>

#pragma comment(lib, "winmm.lib")
using namespace std;
void color(int);

class Colorform {
public:
	string str[50];
	int origin_color[50];
	int change_color[50];
	Colorform() {

		origin_color[0] = 64;
		origin_color[1] = 96;
		origin_color[2] = 32;
		origin_color[3] = 48;
		origin_color[4] = 80;
		origin_color[5] = 224;
		origin_color[6] = 176;
	

		change_color[0] = 192;
		change_color[1] = 224;
		change_color[2] = 160;
		change_color[3] = 176;
		change_color[4] = 208;
		change_color[5] = 112;
		change_color[6] = 240;
	}
	Colorform(int) {
	
		origin_color[0] = 4;
		origin_color[1] = 6;
		origin_color[2] = 2;
		origin_color[3] = 9;
		origin_color[4] = 5;
		origin_color[5] = 14;
		origin_color[6] = 11;

		change_color[0] = 12;
		change_color[1] = 6;
		change_color[2] = 10;
		change_color[3] = 9;
		change_color[4] = 13;
		change_color[5] = 14;
		change_color[6] = 11;

	}
};
class Keyboard {
private:
	string str[10];
	int number;
	Colorform kb_color;

public:
	char in;
	void changecolor(char);
	void sounds();
	void getin() { in = _getch(); }
	void initialcolor();
	void Rf_keyboard(int);
};
class title {
private:
	string song_words[20];
	int key_words[20][20];
	int mark[20][2];
	int line;
	Colorform tt_color;
	int mark_i;
	int mark_j;
	int is_re;
public:
	int Count;
	title() :tt_color(1) {
		Count = 0;
	
	}
	void Rf_title(int);
	void initialtitle();
	void changetitle(char);
};
class Container :public Keyboard, public title
{
public:
	int react();
};

