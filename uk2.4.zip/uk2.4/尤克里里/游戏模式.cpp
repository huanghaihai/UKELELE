#include"play.h"
#include"game.h"
void Display::welcome() {

	cout << "                                                                 " << endl;
	cout << "           #####                                                 " << endl;
	cout << "           ##  ##                     #    ##                   " << endl;
	cout << "           ##   ##    #####  ######   #   ######                " << endl;
	cout << "           ##   ##    ## ##  ##  ##        ##                   " << endl;
	cout << "           ##   ##    ## ##  ##  ##        ##                   " << endl;
	cout << "           ######     #####  ##  ##        #####                " << endl << endl;

	cout << "                                                   ##                    " << endl;
	cout << "          ##      ######    ##    ##    #####      ##                    " << endl;
	cout << "       ########  ##    ##   ##    ##   ##    #     #######                 " << endl;
	cout << "          ##     ##    ##   ##    ##   ##          ##   ##                 " << endl;
	cout << "          ##     ##    ##   ##    ##   ##    #     ##   ##                " << endl;
	cout << "          #####   ######     ######     #####      ##   ##                  " << endl;
	cout << "                                                                  " << endl;
	cout << "     $$        $$                               $$    $$         " << endl;
	cout << "     $$        $$                   $$$$$       $$  $$       " << endl;
	cout << "     $$        $$     $$$$$        $$    $      $$$$          " << endl;
	cout << "     $$$$$$    $$    $$    $$      $$           $$$$         " << endl;
	cout << "     $$   $$   $$    $$    $$      $$    $      $$  $$        " << endl;
	cout << "     $$$$$$    $$     $$$$  $$      $$$$$       $$    $$    " << endl << endl;
	cout << "     ��Ϸ���򣺰��� 1��2��3��4 ���ּ����㶨������Ŀ��" << endl << endl;
	cout << "\t\t";

	system("PAUSE");
}

int Display::show(int t) {

	system("cls");
	int i;//����ֵ
	SYSTEMTIME time;
	GetLocalTime(&time);
	x = (time.wMilliseconds / 100 % 4) + 1;

	if (t<94) {
		switch (d) {
		case 1:
			b1();
			break;
		case 2:
			b2();
			break;
		case 3:
			b3();
			break;
		case 4:
			b4();
			break;
		}

		switch (c) {
		case 1:
			b1();
			break;
		case 2:
			b2();
			break;
		case 3:
			b3();
			break;
		case 4:
			b4();
			break;
		}
		switch (b) {
		case 1:
			b1();
			break;
		case 2:
			b2();
			break;
		case 3:
			b3();
			break;
		case 4:
			b4();
			break;
		}
		switch (a) {
		case 1:
			b1();
			break;
		case 2:
			b2();
			break;
		case 3:
			b3();
			break;
		case 4:
			b4();
			break;
		}
	}

	else {
		cout << endl << endl << endl << endl << endl << endl;
		if (t<96) {
			switch (c) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
		}
		else { cout << endl << endl << endl << endl << endl << endl; }
		if (t<98) {
			switch (b) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
		}
		else { cout << endl << endl << endl << endl << endl << endl; }
		if (t<100) {
			switch (a) {
			case 1:
				b1();
				break;
			case 2:
				b2();
				break;
			case 3:
				b3();
				break;
			case 4:
				b4();
				break;
			}
		}
		else { cout << "............................................................" << endl << "............................................................" << endl << "............................................................" << endl << "............................................................" << endl << "............................................................" << endl; }
	}

	i = a;
	a = b; b = c; c = d; d = x;

	cout << endl << " 1111111111111   2222222222222   3333333333333   4444444444444" << endl;
	Beep(1000, 100);

	return i;
}

void Display::b1() {
	color(255);

	cout << "###############" << endl;
	cout << "###############" << endl;
	cout << "###############" << endl;
	cout << "###############" << endl;
	cout << "###############" << endl;
	cout << "###############" << endl;
	color(7);
}
void Display::b2() {
	color(7);
	cout << "                ";
	color(255);
	cout<<"###############" << endl;
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl;
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl; 
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl; 
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl; 
	color(7);
	cout << "                ";
	color(255);
	cout << "###############" << endl;
	color(7);
}
void Display::b3() {
	color(7);
	cout << "                                ";
	color(255);
    cout<<"###############" << endl;
	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;	color(7);
	cout << "                                ";
	color(255);
	cout << "###############" << endl;
	color(7);
}

void Display::b4() {
	color(7);
	cout << "                                                ";
	color(255);
    cout<<"###############" << endl;
	color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl; color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl; color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl; color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl; color(7);
	cout << "                                                ";
	color(255);
	cout << "###############" << endl;
	color(7);
}

void Display::fail() {


	system("cls");

	cout << "                                                                 " << endl;
	cout << "       ###                                 ###                   " << endl;
	cout << "         ###                             ###                     " << endl;
	cout << "           ###                         ###                       " << endl;
	cout << "             ###                     ###                         " << endl;
	cout << "               ###                 ###                           " << endl;
	cout << "                 ###             ###                             " << endl;
	cout << "                   ###         ###                               " << endl;
	cout << "                     ###     ###                                 " << endl;
	cout << "                       ### ###                                   " << endl;
	cout << "                         ###                                     " << endl;
	cout << "                       ### ###                                   " << endl;
	cout << "                     ###     ###                                 " << endl;
	cout << "                   ###         ###                               " << endl;
	cout << "                 ###             ###                             " << endl;
	cout << "               ###                 ###                           " << endl;
	cout << "             ###                     ###                         " << endl;
	cout << "           ###                         ###                       " << endl;
	cout << "         ###                             ###                     " << endl;
	cout << "       ###                                 ###                   " << endl << endl;


	//Ӧ�����������һ������
	Beep((DWORD)1000, (DWORD)500);


}

void Display::win() {
	system("cls");
	cout << "you win!" << endl;
	system("pause");
}

void Display::inital(int j)
{
	int i;
	switch (j) 
	{
	case 1:
		SYSTEMTIME time;
		GetLocalTime(&time);
	    i = time.wMilliseconds;
		a = (i % 4) + 1;
		b = (i / 10 % 4) + 1;
		c = (i / 100 % 4) + 1;
		d = (a + b + c) % 4 + 1;
		break;
	case 2:
		break;
	
	}

}


